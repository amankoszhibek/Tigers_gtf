# Tigers Team Taekwondo — сайт секции

Статический сайт (HTML + CSS), без сборки и зависимостей.

## Структура
- `index.html` — вся страница
- `assets/images/` — фото, эмблема, мерч
- `assets/video/` — видео

## Как выложить на GitHub Pages
1. Создайте репозиторий на github.com (кнопка **New**), например `tigers-site`.
2. Загрузите содержимое этой папки: **Add file → Upload files**, перетащите `index.html`, `.nojekyll`, `README.md` и папку `assets`, нажмите **Commit changes**.
3. Откройте **Settings → Pages**. В разделе **Build and deployment** выберите **Deploy from a branch**, ветку `main` и папку `/ (root)`, нажмите **Save**.
4. Через 1–2 минуты сайт появится по адресу `https://ВАШ-ЛОГИН.github.io/tigers-site/`.

## Что где менять
- Телефон: ищите `+77780610996` и `8 778 061 0996` в `index.html`.
- Расписание и адреса: секции `#schedule` и `#faq`.
- Фото: замените файлы в `assets/images/` с тем же именем.
- Видео: замените файлы в `assets/video/`.
